document.addEventListener("DOMContentLoaded", function() {
    const searchInput = document.querySelector('input[name="name"]');
    const searchIcon = document.querySelector('.fa-search');

    searchIcon.addEventListener("click", function() {
        const searchValue = searchInput.value.trim();
        if (searchValue) {
            // Chuyển hướng đến trang "boloc.html" với tham số truyền theo tên đã nhập
            window.location.href = `boloc.html?name=${searchValue}`;
        }
    });
});
