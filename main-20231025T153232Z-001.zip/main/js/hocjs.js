// var / const le



{
    let b = 2;
}
console.log(b);