var courseApi = 'http://localhost:3000/courses';
let productFilter = [];
let data = null;
function filterByName(name) {
    if (data !== null) {
        const filteredProducts = data.filter(item => item.ten.toLowerCase().includes(name.toLowerCase()));
        showProduct(filteredProducts);
        count.innerText = filteredProducts.length;
    }
}
function start() {
    getCourses().then(function(responseData) {
        data = responseData; 
        showProduct(data);
        // Lấy tham số "name" từ URL
        const urlParams = new URLSearchParams(window.location.search);
        const searchName = urlParams.get('name');

        // Kiểm tra nếu tham số "name" có giá trị thì thực hiện tìm kiếm
        if (searchName !== null) {
            filterByName(searchName);
        }
    });
}

function getCourses() {
    return fetch(courseApi)
        .then(function (response) {
            return response.json();
        })
        .catch(function (error) {
            console.error("Lỗi khi tải dữ liệu: " + error);
        });
}

let list = document.getElementById('list');
let filter = document.querySelector('.filter');
let count = document.getElementById('count');

function showProduct(productFilter) {
    count.innerText = productFilter.length;
    console.log(count.innerText);
    list.innerHTML = '';
    productFilter.forEach(item => {
        // Tạo và hiển thị các sản phẩm tương ứng ở đây
        // create new div có class = "product-gallery-one-content-product-item"
        let newDiv1 = document.createElement('div');
        newDiv1.classList.add('product-gallery-one-content-product-item');

        // create image
        let newImage = document.createElement('img');
        newImage.src = "imgdetail/" + item.img1;
        newDiv1.appendChild(newImage);

        // create new div có class = "product-gallery-one-content-product-item-text"
        let newDiv2 = document.createElement('div');
        newDiv2.classList.add('product-gallery-one-content-product-item-text');
        newDiv1.appendChild(newDiv2);

        // create product number
        let newNumber = document.createElement('li');
        newNumber.textContent = "Tồn kho: " + item.sltk;
        newDiv2.appendChild(newNumber);

        let newName = document.createElement('li');
        let newNamea = document.createElement('a');
        newNamea.target = "_blank";
        let productID = item.id; 
        let productURL = "detail.html?id=" + productID;

        newNamea.href = productURL;
        newNamea.textContent = item.ten; 
        newName.appendChild(newNamea);
        newDiv2.appendChild(newName);


        // create chip product 
        let newChip = document.createElement('li');
        newChip.textContent = item.chipset;
        newDiv2.appendChild(newChip);

        // create product old price
        let newOldPrice = document.createElement('li');
        newOldPrice.textContent = item.giacu;
        newDiv2.appendChild(newOldPrice);

        // create product new price
        let newNewPrice = document.createElement('li');
        newNewPrice.textContent = item.giamoi;
        newDiv2.appendChild(newNewPrice);

        // create HDH product 
        let newHDH = document.createElement('li');
        newHDH.textContent = item.hedieuhanh;
        newDiv2.appendChild(newHDH);

        // create product rating
        let newRate = document.createElement('li');
        newRate.textContent = "Rate: " + item.rate;
        newDiv2.appendChild(newRate);

        list.appendChild(newDiv1);
    });
}

document.addEventListener("DOMContentLoaded", function() {
    // Lấy tham chiếu đến các phần tử DOM cần thiết
    let list = document.getElementById('list');
    let filter = document.querySelector('.filter');
    let count = document.getElementById('count');

    // Xử lý sự kiện submit của bộ lọc
    filter.addEventListener('submit', function (event) {
        event.preventDefault();

        if (data !== null) {
            let valueFilter = {
                hang: '',
                RAM: '',
                ROM: '',
                name: '',
                minPrice: '',
                maxPrice: '',
            };

            valueFilter.hang = event.target.querySelector('select[name="hang"]').value;
            valueFilter.RAM = event.target.querySelector('select[name="RAM"]').value;
            valueFilter.ROM = event.target.querySelector('select[name="ROM"]').value;
            valueFilter.minPrice = event.target.querySelector('input[name="minPrice"]').value;
            valueFilter.maxPrice = event.target.querySelector('input[name="maxPrice"]').value;

            productFilter = data.filter(item => {
                // Filter conditions
                if (valueFilter.hang !== '' && item.hang !== valueFilter.hang) {
                    return false;
                }
                if (valueFilter.RAM !== '' && item.RAM !== valueFilter.RAM) {
                    return false;
                }
                if (valueFilter.ROM !== '' && item.ROM !== valueFilter.ROM) {
                    return false;
                }
                if (valueFilter.minPrice !== '' && parseFloat(item.gia) < parseFloat(valueFilter.minPrice)) {
                    return false;
                }
                if (valueFilter.maxPrice !== '' && parseFloat(item.gia) > parseFloat(valueFilter.maxPrice)) {
                    return false;
                }
                return true;
            });
            count.innerText = productFilter.length;
            showProduct(productFilter);
        }
    });

});

start();